from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, DeclarativeBase

# движок БД
engine = create_engine('sqlite:///taskmanager.db', echo=True)

# сессия БД
SessionLocal = sessionmaker(bind=engine)

# класс нашей БД
# для того чтобы сопоставлять классы модели Pydantic и базы данных
class Base(DeclarativeBase):
    pass