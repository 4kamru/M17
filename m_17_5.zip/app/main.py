from fastapi import FastAPI
from app.routers import task, user
from app.backend.db import Base, engine
from app.models import User, Task

app = FastAPI()

# Создаём таблицы
Base.metadata.create_all(bind=engine)

@app.get('/')
async def welcome():
    return {'message': 'Welcome to Taskmanager'}


app.include_router(task.router)
app.include_router(user.router)

# 1 - команда установки alembic
# pip install alembic
# 2 - команда инициализации механизма миграции
# alembic init app/migrations
# 3 - команда 1-й миграции (ревизии)
# alembic revision --autogenerate -m "Initial migration"
# 4 - Выполните команду
# alembic upgrade head
# создать таблицы User, Task и запись текущей версии миграции

